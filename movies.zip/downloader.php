<?php


$url = 'http://31.mangovideo.pw/contents/videos//31000/31836/31836.mp4';
